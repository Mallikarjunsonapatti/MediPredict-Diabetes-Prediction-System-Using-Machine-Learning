# d_app.py
import streamlit as st
import joblib
import os
import numpy as np

# -----------------------------
# Step 1: Load the trained model safely
# -----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(BASE_DIR, "model.joblib")

try:
    model = joblib.load(model_path)
    st.success("Model loaded successfully!")
except FileNotFoundError:
    st.error(f"Model file not found at {model_path}")
    st.stop()  # Stop the app if model not found

# -----------------------------
# Step 2: Streamlit UI
# -----------------------------
st.title("MediPredict - Diabetes Prediction")

st.write("Enter the following details:")

# Input fields for 8 features used in diabetes dataset
pregnancies = st.number_input("Pregnancies", 0, 20, 0)
glucose = st.number_input("Glucose Level", 0, 300, 120)
blood_pressure = st.number_input("Blood Pressure", 0, 200, 70)
skin_thickness = st.number_input("Skin Thickness", 0, 100, 20)
insulin = st.number_input("Insulin", 0, 900, 79)
bmi = st.number_input("BMI", 0.0, 70.0, 20.0)
dpf = st.number_input("Diabetes Pedigree Function", 0.0, 2.5, 0.5)
age = st.number_input("Age", 0, 120, 30)

# -----------------------------
# Step 3: Predict button
# -----------------------------
if st.button("Predict"):
    # Prepare input for the model
    input_data = np.array([[pregnancies, glucose, blood_pressure, skin_thickness,
                            insulin, bmi, dpf, age]])
    prediction = model.predict(input_data)[0]

    if prediction == 1:
        st.error("⚠️ The model predicts: Diabetes Positive")
    else:
        st.success("✅ The model predicts: Diabetes Negative")
