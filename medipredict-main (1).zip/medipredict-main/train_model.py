# train_model.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

# -----------------------------
# Step 1: Set correct CSV path
# -----------------------------
# Get folder where this script is located
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(BASE_DIR, "diabetes.csv")

# -----------------------------
# Step 2: Load dataset
# -----------------------------
try:
    data = pd.read_csv(csv_path)
    print("CSV loaded successfully!")
except FileNotFoundError:
    print(f"ERROR: File not found at {csv_path}")
    exit()  # Stop the script if CSV not found

# -----------------------------
# Step 3: Prepare features and target
# -----------------------------
X = data.drop("Outcome", axis=1)
y = data["Outcome"]

# -----------------------------
# Step 4: Split data into train/test
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# -----------------------------
# Step 5: Train model
# -----------------------------
clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)
print("Model trained successfully!")

# -----------------------------
# Step 6: Save the trained model
# -----------------------------
model_path = os.path.join(BASE_DIR, "model.joblib")
joblib.dump(clf, model_path)
print(f"Model saved successfully at {model_path}")
