import pickle
import joblib

# Load old pickle
with open("model.pkl", "rb") as f:
    model = pickle.load(f)

# Save as joblib
joblib.dump(model, "model.joblib")

print("Conversion successful! model.joblib is ready.")
